# -*- coding: utf-8 -*-
"""Simulated corridor people counter (End-term, Part D3).
Every few seconds it writes generated readings into the table corridor_counts of queue.sqlite.
The administrator Statistics screen of the bot shows the latest value.
Run in a second terminal:  python sensor_sim.py      (stop with Ctrl+C)"""
import os, random, sqlite3, time
from datetime import datetime

DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "queue.sqlite"))
EVERY = 3   # seconds between readings

db = sqlite3.connect(DB_PATH)
db.execute("""CREATE TABLE IF NOT EXISTS corridor_counts (
    id INTEGER PRIMARY KEY,
    counted_at TEXT NOT NULL,
    people_in INTEGER NOT NULL CHECK (people_in >= 0),
    people_out INTEGER NOT NULL CHECK (people_out >= 0),
    people_now INTEGER NOT NULL CHECK (people_now >= 0))""")
db.commit()
row = db.execute("SELECT people_now FROM corridor_counts ORDER BY id DESC LIMIT 1").fetchone()
now_inside = row[0] if row else 5
print("Sensor simulation started. Press Ctrl+C to stop.")
try:
    while True:
        p_in, p_out = random.choice([0, 1, 1, 2]), random.choice([0, 1, 1, 2])
        p_out = min(p_out, now_inside + p_in)            # nobody can leave if nobody is inside
        now_inside += p_in - p_out
        db.execute("INSERT INTO corridor_counts(counted_at, people_in, people_out, people_now) VALUES (?,?,?,?)",
                   (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), p_in, p_out, now_inside))
        db.commit()
        print(f"in={p_in} out={p_out} now={now_inside}")
        time.sleep(EVERY)
except KeyboardInterrupt:
    print("Stopped.")
